package com.project.uma.euro;


public class Team implements Comparable<Team> {

    private final String id;

    private int points;
    
    private int butsMarques;

    private int butsEcaisses;

    public Team(String id) {
        super();
        this.id = id;
        this.points = 0;
        this.butsMarques = 0;
        this.butsEcaisses = 0;
    };

    protected String getId() {
        return this.id;
    }

    protected int getPoints() {
        return this.points;
    }

    protected int getButsMarques() {
        return this.butsMarques;
    }

    protected int getButsEcaisses() {
        return this.butsEcaisses;
    }

    public int getGoalAverage() {
        return this.butsMarques - this.butsEcaisses;
    }

    public void gagne(int butsMarques, int butsEcaisses) {
        this.points += 3;
        this.butsMarques += butsMarques;
        this.butsEcaisses += butsEcaisses;
    }

    public void matchNul(int butsMarques, int butsEcaisses) {
        this.points += 1;
        this.butsMarques += butsMarques;
        this.butsEcaisses += butsEcaisses;
    }

    public void perd(int butsMarques,int butsEcaisses) {
        this.butsMarques += butsMarques;
        this.butsEcaisses += butsEcaisses;
    }

    @Override
    public int compareTo(Team t) {
        if (this.points > t.getPoints()){
            return -1;
        } else if (this.points < t.getPoints()) {
            return 1;
        }

        // cas d'egalite aux points :
        if (this.getGoalAverage() > t.getGoalAverage()) {
            return -1;
        } else if (this.getGoalAverage() < t.getGoalAverage()) {
            return 1;
        }

        // meilleure attaque
        if (this.butsMarques > t.getButsMarques()) {
            return -1;
        } else if (this.butsMarques < t.getButsMarques()) {
            return 1;
        }

        // cas d'egalite a la diff: on tri par ordre alphabetique
        return this.getId().compareTo(t.getId());

    }

}
