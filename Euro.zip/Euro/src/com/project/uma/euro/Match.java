package com.project.uma.euro;


public class Match {

    private final Team team1;

    private final int score1;

    private final Team team2;

    private final int score2;

    public Match(Team team1, int score1, Team team2, int score2) {
        super();
        this.team1 = team1;
        this.score1 = score1;
        this.team2 = team2;
        this.score2 = score2;

        this.traiter();
    }

    private void traiter() {

        if (this.score1 > this.score2) {
            this.team1.gagne(this.score1, this.score2);
            this.team2.perd(this.score2, this.score1);
        } else if (this.score1 < this.score2) {
            this.team2.gagne(this.score2, this.score1);
            this.team1.perd(this.score1, this.score2);
        } else if (this.score1 == this.score2) {
            this.team1.matchNul(this.score1, this.score2);
            this.team2.matchNul(this.score2, this.score1);
        }

    }

}
