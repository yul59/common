package com.project.uma.euro;

import java.util.Comparator;
import java.util.Map;


public class TeamComparator implements Comparator<String> {

    private final Map<String, Team> map;

    public TeamComparator(Map<String, Team> map) {
        super();
        this.map = map;
    }

    @Override
    public int compare(String cle1, String cle2) {
        return this.map.get(cle1).compareTo(this.map.get(cle2));
    }

}
