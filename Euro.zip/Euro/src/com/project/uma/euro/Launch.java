package com.project.uma.euro;

import com.project.uma.evt.Evenement;
import com.project.uma.evt.EvenementDetail;
import com.project.uma.evt.EvenementListe;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;


public class Launch {

    public static void main(String[] args) {
        genererClass();

        // gestionEvt();

    }

    private static void gestionEvt() {
        final EvenementDetail evtDetail1 = new EvenementDetail(1, "evtDetail 1");
        final EvenementDetail evtDetail2 = new EvenementDetail(2, "evtDetail 2");
        final EvenementDetail evtDetail3 = new EvenementDetail(3, "evtDetail 3");
        final EvenementDetail evtDetail4 = new EvenementDetail(4, "evtDetail 4");
        final EvenementDetail evtDetail5 = new EvenementDetail(5, "evtDetail 5");

        final Evenement evt5 = new Evenement(5, evtDetail5, null, null);
        final Evenement evt4 = new Evenement(4, evtDetail4, null, null);
        final Evenement evt3 = new Evenement(3, evtDetail3, null, null);
        final Evenement evt2 = new Evenement(2, evtDetail2, evt4, evt5);
        final Evenement evt1 = new Evenement(1, evtDetail1, evt2, evt3);

        final EvenementListe liste1 = new EvenementListe(1, evt1);

        System.out.println(liste1.toString());

    }

    private static void genererClass() {

        // GR A
        final HashMap<String, Team> grpA = new HashMap<String, Team>();
        grpA.put("FRA", new Team("FRA"));
        grpA.put("ROU", new Team("ROU"));
        grpA.put("SUI", new Team("SUI"));
        grpA.put("ALB", new Team("ALB"));

        final List<Match> matchA = new ArrayList<Match>();
        matchA.add(new Match(grpA.get("FRA"), 3, grpA.get("ROU"), 1));
        matchA.add(new Match(grpA.get("ALB"), 0, grpA.get("SUI"), 0));
        matchA.add(new Match(grpA.get("ROU"), 0, grpA.get("SUI"), 0));
        matchA.add(new Match(grpA.get("FRA"), 2, grpA.get("ALB"), 0));
        matchA.add(new Match(grpA.get("ROU"), 1, grpA.get("ALB"), 0));
        matchA.add(new Match(grpA.get("SUI"), 1, grpA.get("FRA"), 1));

        donneClass("GROUPE A", grpA);

        // GR B
        final HashMap<String, Team> grpB = new HashMap<String, Team>();
        grpB.put("GAL", new Team("GAL"));
        grpB.put("RUS", new Team("RUS"));
        grpB.put("ANG", new Team("ANG"));
        grpB.put("SLO", new Team("SLO"));

        final List<Match> matchB = new ArrayList<Match>();
        matchB.add(new Match(grpB.get("GAL"), 0, grpB.get("SLO"), 0));
        matchB.add(new Match(grpB.get("ANG"), 0, grpB.get("RUS"), 0));
        matchB.add(new Match(grpB.get("RUS"), 2, grpB.get("SLO"), 1));
        matchB.add(new Match(grpB.get("ANG"), 2, grpB.get("GAL"), 1));
        matchB.add(new Match(grpB.get("SLO"), 1, grpB.get("ANG"), 3));
        matchB.add(new Match(grpB.get("RUS"), 1, grpB.get("GAL"), 1));

        donneClass("GROUPE B", grpB);

        // GR C
        final HashMap<String, Team> grpC = new HashMap<String, Team>();
        grpC.put("ALL", new Team("ALL"));
        grpC.put("ILN", new Team("ILN"));
        grpC.put("UKR", new Team("UKR"));
        grpC.put("POL", new Team("POL"));

        final List<Match> matchC = new ArrayList<Match>();
        matchC.add(new Match(grpC.get("ALL"), 1, grpC.get("UKR"), 0));
        matchC.add(new Match(grpC.get("POL"), 1, grpC.get("ILN"), 0));
        matchC.add(new Match(grpC.get("UKR"), 0, grpC.get("ILN"), 0));
        matchC.add(new Match(grpC.get("ALL"), 0, grpC.get("POL"), 0));
        matchC.add(new Match(grpC.get("ILN"), 0, grpC.get("ALL"), 2));
        matchC.add(new Match(grpC.get("UKR"), 0, grpC.get("POL"), 1));

        donneClass("GROUPE C", grpC);

        // GR D
        final HashMap<String, Team> grpD = new HashMap<String, Team>();
        grpD.put("TUR", new Team("TUR"));
        grpD.put("ESP", new Team("ESP"));
        grpD.put("CRO", new Team("CRO"));
        grpD.put("RTC", new Team("RTC"));

        final List<Match> matchD = new ArrayList<Match>();
        matchD.add(new Match(grpD.get("TUR"), 0, grpD.get("CRO"), 0));
        matchD.add(new Match(grpD.get("ESP"), 2, grpD.get("RTC"), 0));
        matchD.add(new Match(grpD.get("ESP"), 0, grpD.get("TUR"), 0));
        matchD.add(new Match(grpD.get("RTC"), 0, grpD.get("CRO"), 1));
        matchD.add(new Match(grpD.get("RTC"), 0, grpD.get("TUR"), 1));
        matchD.add(new Match(grpD.get("CRO"), 0, grpD.get("ESP"), 2));

        donneClass("GROUPE D", grpD);

        // GR E
        final HashMap<String, Team> grpE = new HashMap<String, Team>();
        grpE.put("ITA", new Team("ITA"));
        grpE.put("SUE", new Team("SUE"));
        grpE.put("IRL", new Team("IRL"));
        grpE.put("BEL", new Team("BEL"));

        final List<Match> matchE = new ArrayList<Match>();
        matchE.add(new Match(grpE.get("BEL"), 0, grpE.get("ITA"), 0));
        matchE.add(new Match(grpE.get("IRL"), 0, grpE.get("SUE"), 1));
        matchE.add(new Match(grpE.get("ITA"), 1, grpE.get("SUE"), 0));
        matchE.add(new Match(grpE.get("BEL"), 2, grpE.get("IRL"), 1));
        matchE.add(new Match(grpE.get("ITA"), 2, grpE.get("IRL"), 0));
        matchE.add(new Match(grpE.get("SUE"), 2, grpE.get("BEL"), 2));

        donneClass("GROUPE E", grpE);

        // GR F
        final HashMap<String, Team> grpF = new HashMap<String, Team>();
        grpF.put("ISL", new Team("ISL"));
        grpF.put("AUT", new Team("AUT"));
        grpF.put("POR", new Team("POR"));
        grpF.put("HON", new Team("HON"));

        final List<Match> matchF = new ArrayList<Match>();
        matchF.add(new Match(grpF.get("AUT"), 0, grpF.get("HON"), 0));
        matchF.add(new Match(grpF.get("POR"), 1, grpF.get("ISL"), 1));
        matchF.add(new Match(grpF.get("ISL"), 0, grpF.get("HON"), 0));
        matchF.add(new Match(grpF.get("POR"), 1, grpF.get("AUT"), 0));
        matchF.add(new Match(grpF.get("ISL"), 1, grpF.get("AUT"), 1));
        matchF.add(new Match(grpF.get("HON"), 0, grpF.get("POR"), 1));

        donneClass("GROUPE F", grpF);
    }

    private static void donneClass(String groupName, HashMap<String, Team> grp) {

        final TeamComparator comparateur = new TeamComparator(grp);
        final TreeMap<String, Team> grpTri = new TreeMap<String, Team>(comparateur);
        grpTri.putAll(grp);

        System.out.println(groupName);
        System.out.println("======================");

        for (final String mapKey : grpTri.keySet()) {
            final Team t = grpTri.get(mapKey);
            final StringBuffer s = new StringBuffer(t.getId());
            s.append("\t")
                .append(t.getPoints())
                .append(" pts ")
                .append("(")
                .append(t.getButsMarques())
                .append("/")
                .append(t.getButsEcaisses())
                .append("/")
                .append(t.getGoalAverage())
                .append(")");
            System.out.println(s);
        }

        System.out.println();

    }


}
