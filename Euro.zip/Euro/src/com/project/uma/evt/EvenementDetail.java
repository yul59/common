package com.project.uma.evt;

/**
 * The Class EvenementDetail.
 */
public class EvenementDetail {

    /** The id. */
    private int id;

    /** The libelle. */
    private String libelle;

    /**
     * Instantiates a new evenement detail.
     * @param id the id
     * @param libelle the libelle
     */
    public EvenementDetail(int id, String libelle) {
        super();
        this.id = id;
        this.libelle = libelle;
    }

    /**
     * Gets the id.
     * @return the id
     */
    protected int getId() {
        return this.id;
    }

    /**
     * Sets the id.
     * @param id the new id
     */
    protected void setId(int id) {
        this.id = id;
    }

    /**
     * Gets the libelle.
     * @return the libelle
     */
    protected String getLibelle() {
        return this.libelle;
    }

    /**
     * Sets the libelle.
     * @param libelle the new libelle
     */
    protected void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    @Override
    public String toString() {
        return "EvenementDetail [id=" + this.id + ", libelle=" + this.libelle + "]";
    }

}
