package com.project.uma.evt;


/**
 * The Class EvenementListe.
 */
public class EvenementListe {

    /** The id. */
    private int id;

    /** The evt. */
    private Evenement evt;

    /**
     * Instantiates a new evenement liste.
     * @param id the id
     * @param evt the evt
     */
    public EvenementListe(int id, Evenement evt) {
        super();
        this.id = id;
        this.evt = evt;
    }

    /**
     * Gets the id.
     * @return the id
     */
    protected int getId() {
        return this.id;
    }

    /**
     * Sets the id.
     * @param id the new id
     */
    protected void setId(int id) {
        this.id = id;
    }

    /**
     * Gets the evt.
     * @return the evt
     */
    protected Evenement getEvt() {
        return this.evt;
    }

    /**
     * Sets the evt.
     * @param evt the new evt
     */
    protected void setEvt(Evenement evt) {
        this.evt = evt;
    }

    @Override
    public String toString() {
        return "EvenementListe [id=" + this.id + ", evt=" + this.evt + "]";
    }

}
