package com.project.uma.evt;


/**
 * The Class Evenement.
 */
public class Evenement {

    /** The id. */
    private int id;

    /** The detail. */
    private EvenementDetail detail;

    /** The Evenement suivant ok. */
    private Evenement EvenementSuivantOk;

    /** The Evenement suivant nok. */
    private Evenement EvenementSuivantNok;

    /**
     * Instantiates a new evenement.
     * @param id the id
     * @param detail the detail
     * @param evenementSuivantOk the evenement suivant ok
     * @param evenementSuivantNok the evenement suivant nok
     */
    public Evenement(int id, EvenementDetail detail, Evenement evenementSuivantOk, Evenement evenementSuivantNok) {
        super();
        this.id = id;
        this.detail = detail;
        this.EvenementSuivantOk = evenementSuivantOk;
        this.EvenementSuivantNok = evenementSuivantNok;
    }

    /**
     * Gets the id.
     * @return the id
     */
    protected int getId() {
        return this.id;
    }

    /**
     * Sets the id.
     * @param id the new id
     */
    protected void setId(int id) {
        this.id = id;
    }

    protected EvenementDetail getDetail() {
        return this.detail;
    }

    /**
     * Sets the detail.
     * @param detail the new detail
     */
    protected void setDetail(EvenementDetail detail) {
        this.detail = detail;
    }

    /**
     * Gets the evenement suivant ok.
     * @return the evenement suivant ok
     */
    protected Evenement getEvenementSuivantOk() {
        return this.EvenementSuivantOk;
    }

    /**
     * Sets the evenement suivant ok.
     * @param evenementSuivantOk the new evenement suivant ok
     */
    protected void setEvenementSuivantOk(Evenement evenementSuivantOk) {
        this.EvenementSuivantOk = evenementSuivantOk;
    }

    /**
     * Gets the evenement suivant nok.
     * @return the evenement suivant nok
     */
    protected Evenement getEvenementSuivantNok() {
        return this.EvenementSuivantNok;
    }

    /**
     * Sets the evenement suivant nok.
     * @param evenementSuivantNok the new evenement suivant nok
     */
    protected void setEvenementSuivantNok(Evenement evenementSuivantNok) {
        this.EvenementSuivantNok = evenementSuivantNok;
    }

    @Override
    public String toString() {
        return "Evenement [id=" + this.id + ", detail=" + this.detail + ", EvenementSuivantOk="
                + this.EvenementSuivantOk + ", EvenementSuivantNok=" + this.EvenementSuivantNok + "]";
    }

}
