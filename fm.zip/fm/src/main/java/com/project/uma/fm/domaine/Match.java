package com.project.uma.fm.domaine;

import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class Match.
 */
public class Match {

    private static final Logger logger = LoggerFactory.getLogger(Match.class);

    /** The equipe rec. */
    private final Equipe equipeRec;

    /** The score eq rec. */
    private int scoreEqRec;

    /** The equipe vis. */
    private final Equipe equipeVis;

    /** The score eq vis. */
    private int scoreEqVis;

    /**
     * Instantiates a new match.
     * @param equipeRec the equipe rec
     * @param scoreEqRec the score eq rec
     * @param equipeVis the equipe vis
     * @param scoreEqVis the score eq vis
     */
    public Match(Equipe equipeRec, int scoreEqRec, Equipe equipeVis, int scoreEqVis) {
        super();
        this.equipeRec = equipeRec;
        this.scoreEqRec = scoreEqRec;
        this.equipeVis = equipeVis;
        this.scoreEqVis = scoreEqVis;
        this.jouer();
    }

    /**
     * Jouer.
     */
    public void jouer() {

        logger.debug("test");

        // System.out.println("equip rec avant match = " + this.equipeRec);
        // System.out.println("equip vis avant match = " + this.equipeVis);

        final int valMin = 0;
        final int valMax = 4;
        final Random rand = new Random();
        this.scoreEqRec = rand.nextInt(valMax - valMin + 1) + valMin;
        this.scoreEqVis = rand.nextInt(valMax - valMin + 1) + valMin;
        
        if (this.scoreEqRec > this.scoreEqVis) {
            this.equipeRec.gagne(this.scoreEqRec, this.scoreEqVis);
            this.equipeVis.perd(this.scoreEqVis, this.scoreEqRec);
        } else if (this.scoreEqRec < this.scoreEqVis) {
            this.equipeVis.gagne(this.scoreEqVis, this.scoreEqRec);
            this.equipeRec.perd(this.scoreEqRec, this.scoreEqVis);
        } else if (this.scoreEqRec == this.scoreEqVis) {
            this.equipeRec.matchNul(this.scoreEqRec, this.scoreEqVis);
            this.equipeVis.matchNul(this.scoreEqVis, this.scoreEqRec);
        }

        // System.out.println("equip rec apres match = " + this.equipeRec);
        // System.out.println("equip vis apres match = " + this.equipeVis);
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return String.format("%1$s-%2$s:%3$d-%4$d", this.equipeRec.getName(), this.equipeVis.getName(),
                this.scoreEqRec, this.scoreEqVis);
    }

}
