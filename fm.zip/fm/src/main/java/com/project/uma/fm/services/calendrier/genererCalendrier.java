package com.project.uma.fm.services.calendrier;

import com.project.uma.fm.domaine.Equipe;
import com.project.uma.fm.domaine.Match;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The Class genererCalendrier.
 */
public class genererCalendrier {

    /** The list equipe. */
    ArrayList<Equipe> listEquipe = new ArrayList<Equipe>();

    // Calendrier avec journee aller - retour
    public Map<Integer, List<Match>> mapCalend;

    /**
     * Instantiates a new generer calendrier.
     * @param listEquipe the list equipe
     */
    public genererCalendrier(ArrayList<Equipe> listEquipe) {
        this.listEquipe = listEquipe;
        this.mapCalend = new HashMap<Integer, List<Match>>();
        this.buildCalendrier();

    }

    public void buildCalendrier() {

        ArrayList<Equipe> listEq = new ArrayList<Equipe>();
        listEq.addAll(0, this.listEquipe);

        // nb de journee aller
        final int nbRound = listEq.size() - 1;
        // nb de journee total
        final int nbJourn = nbRound * 2;

        // init du calendrier
        for (int j = 0; j < nbJourn; j++) {
            this.mapCalend.put(j + 1, new ArrayList<Match>());
        }

        // generer une journee (aller + retour)
        for (int i = 0; i < nbRound; i++) {
            this.genererRound(i + 1, listEq);
            listEq = this.nextRound(listEq);
        }
    }

    private void genererRound(int round, List<Equipe> listEq) {

        // liste des match de la journee aller
        final List<Match> opposAller = this.mapCalend.get(round);
        // liste des match de la journee retour
        List<Match> opposRetour;

        // cas de la derniere journee retour qui correspond a la premeire journee aller
        if (round == 1) {
            opposRetour = this.mapCalend.get((listEq.size() - 1) * 2);
        } else {
            opposRetour = this.mapCalend.get((listEq.size() - 2) + round);
        }

        // nb de match dans la journee
        final int nbOppos = listEq.size() / 2;

        // gestion domicile / exterieur
        boolean inverse;

        for (int i = 0; i < nbOppos; i++) {

            inverse = false;
            if (i == 0) {
                if (round % 2 == 0) {
                    inverse = true;
                }
            } else {
                if (i % 2 > 0) {
                    inverse = true;
                }
            }

            // match obtenu
            // String tmpAller = listEq.get(i).getName() + "-" + listEq.get(i + nbOppos).getName();
            // String tmpRetour = listEq.get(i + nbOppos).getName() + "-" + listEq.get(i).getName();
            // if (inverse) {
            // tmpAller = listEq.get(i + nbOppos).getName() + "-" + listEq.get(i).getName();
            // tmpRetour = listEq.get(i).getName() + "-" + listEq.get(i + nbOppos).getName();
            // }

            Equipe equ1 = listEq.get(i);
            Equipe equ2 = listEq.get(i + nbOppos);

            if (inverse) {
                equ2 = listEq.get(i);
                equ1 = listEq.get(i + nbOppos);

                // matchAller = new Match(listEq.get(i + nbOppos), 0, listEq.get(i), 0);
                // matchRetour = new Match(listEq.get(i), 0, listEq.get(i + nbOppos), 0);

            }

            System.out.println("equip rec avant match aller = " + equ1);
            System.out.println("equip vis avant match aller = " + equ2);

            final Match matchAller = new Match(equ1, 0, equ2, 0);

            System.out.println("equip rec apres match aller = " + equ1);
            System.out.println("equip vis apres match aller = " + equ2);

            final Match matchRetour = new Match(equ2, 0, equ1, 0);

            System.out.println("equip rec apres match retour = " + equ1);
            System.out.println("equip vis apres match retour = " + equ2);



            System.out.println(matchAller);
            System.out.println(matchRetour);
            // this.donneClassement();

            // ajouter le match a la journee
            opposAller.add(matchAller);
            opposRetour.add(matchRetour);
        }
    }

    private ArrayList<Equipe> nextRound(ArrayList<Equipe> listEq) {

        // permuter les equipe dans la liste pour generer la journee suivante
        final ArrayList<Equipe> retour = listEq;

        final int indiceSup = (retour.size() / 2);

        Equipe eqSup = retour.remove(indiceSup);
        retour.add(1, eqSup);

        eqSup = retour.remove(indiceSup);
        retour.add(eqSup);

        return retour;
    }


    /**
     * Afficher.
     */
    public void afficher() {

        // for (final Map.Entry<Integer, List<String>> entry : this.mapCalend.entrySet()) {
        // System.out.println("J " + entry.getKey() + " : " + entry.getValue().toString());
        // }

        final int nbJourn = this.mapCalend.size();
        for (int k = 0; k < nbJourn; k++) {
            System.out.println("J " + ((k < 9) ? "0" : "") + (k + 1) + " : " + this.mapCalend.get(k + 1).toString());
            // this.donneClassement();
        }

        this.donneClassement();
    }

    public void donneClassement() {
        Collections.sort(this.listEquipe);
        System.out.println(this.listEquipe);
    }

}
