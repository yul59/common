package com.project.uma.fm.domaine;




/**
 * The Class Equipe.
 */
public class Equipe implements Comparable<Equipe> {

    /** The id. */
    int id;

    /** The name. */
    String name;

    /** The points. */
    private int points;

    /** The buts marques. */
    private int butsMarques;

    /** The buts ecaisses. */
    private int butsEcaisses;

    /**
     * Instantiates a new equipe.
     * @param id the id
     * @param name the name
     */
    public Equipe(int id, String name) {
        this.id = id;
        this.name = name;
        this.points = 0;
        this.butsMarques = 0;
        this.butsEcaisses = 0;
    }

    /**
     * Gets the id.
     * @return the id
     */
    public int getId() {
        return this.id;
    }

    /**
     * Sets the id.
     * @param id the id to set
     */
    private void setId(int id) {
        this.id = id;
    }

    /**
     * Gets the name.
     * @return the name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Sets the name.
     * @param name the name to set
     */
    private void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the points.
     * @return the points
     */
    protected int getPoints() {
        return this.points;
    }

    /**
     * Gets the buts marques.
     * @return the buts marques
     */
    protected int getButsMarques() {
        return this.butsMarques;
    }

    /**
     * Gets the buts ecaisses.
     * @return the buts ecaisses
     */
    protected int getButsEcaisses() {
        return this.butsEcaisses;
    }

    /**
     * Gets the goal average.
     * @return the goal average
     */
    public int getGoalAverage() {
        return this.butsMarques - this.butsEcaisses;
    }

    /**
     * Gagne.
     * @param butsMarques the buts marques
     * @param butsEcaisses the buts ecaisses
     */
    public void gagne(int butsMarques, int butsEcaisses) {
        this.points += 3;
        this.butsMarques += butsMarques;
        this.butsEcaisses += butsEcaisses;
    }

    /**
     * Match nul.
     * @param butsMarques the buts marques
     * @param butsEcaisses the buts ecaisses
     */
    public void matchNul(int butsMarques, int butsEcaisses) {
        this.points += 1;
        this.butsMarques += butsMarques;
        this.butsEcaisses += butsEcaisses;
    }

    /**
     * Perd.
     * @param butsMarques the buts marques
     * @param butsEcaisses the buts ecaisses
     */
    public void perd(int butsMarques, int butsEcaisses) {
        this.butsMarques += butsMarques;
        this.butsEcaisses += butsEcaisses;
    }
    
    /**
     * Compare to.
     * @param equipe the equipe
     * @return the int
     */
    public int compareTo(Equipe equipe) {
        if (this.points > equipe.getPoints()) {
            return -1;
        } else if (this.points < equipe.getPoints()) {
            return 1;
        }

        // cas d'egalite aux points :
        if (this.getGoalAverage() > equipe.getGoalAverage()) {
            return -1;
        } else if (this.getGoalAverage() < equipe.getGoalAverage()) {
            return 1;
        }

        // meilleure attaque
        if (this.butsMarques > equipe.getButsMarques()) {
            return -1;
        } else if (this.butsMarques < equipe.getButsMarques()) {
            return 1;
        }

        // cas d'egalite a la diff: on tri par ordre alphabetique
        return this.getName().compareTo(equipe.getName());

    }

    @Override
    public String toString() {
        return String.format("Equipe [name=%s, points=%s, butsMarques=%s, butsEcaisses=%s]", this.name, this.points,
                this.butsMarques, this.butsEcaisses);
    }

}
