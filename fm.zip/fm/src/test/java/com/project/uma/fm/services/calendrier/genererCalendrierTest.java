package com.project.uma.fm.services.calendrier;

import com.project.uma.fm.domaine.Equipe;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class genererCalendrierTest {

    ArrayList<Equipe> listEquipe = new ArrayList<Equipe>();

    @Before
    public void setUp() {
        this.listEquipe.add(new Equipe(1, "Angers"));
        this.listEquipe.add(new Equipe(2, "Bastia"));
        this.listEquipe.add(new Equipe(3, "Bordeaux"));
        this.listEquipe.add(new Equipe(4, "Caen"));
        // this.listEquipe.add(new Equipe(5, "Dijon"));
        // this.listEquipe.add(new Equipe(6, "Guingamp"));
        // this.listEquipe.add(new Equipe(7, "Lille"));
        // this.listEquipe.add(new Equipe(8, "Lorient"));
        // this.listEquipe.add(new Equipe(9, "Lyon"));
        // this.listEquipe.add(new Equipe(10, "Marseille"));
        // this.listEquipe.add(new Equipe(11, "Metz"));
        // this.listEquipe.add(new Equipe(12, "Monaco"));
        // this.listEquipe.add(new Equipe(13, "Montpellier"));
        // this.listEquipe.add(new Equipe(14, "Nancy"));
        // this.listEquipe.add(new Equipe(15, "Nantes"));
        // this.listEquipe.add(new Equipe(16, "Nice"));
        // this.listEquipe.add(new Equipe(17, "Paris"));
        // this.listEquipe.add(new Equipe(18, "Rennes"));
        // this.listEquipe.add(new Equipe(19, "Saint-Etienne"));
        // this.listEquipe.add(new Equipe(20, "Toulouse"));

    }

    @After
    public void tearDown() {
    }

    @Test
    public void testAfficher() {
        new genererCalendrier(this.listEquipe).afficher();
    }
}
