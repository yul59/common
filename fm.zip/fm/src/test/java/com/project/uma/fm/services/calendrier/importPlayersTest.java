package com.project.uma.fm.services.calendrier;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.junit.Test;

public class importPlayersTest {


    @Test
    public void importTest() throws IOException {

        try {
            // final URL url = importPlayersTest.class.getResource("test.csv");
            // final File f = new File(url.getFile());

            // final InputStream in = this.getClass().getResourceAsStream("test.csv");
            // final InputStreamReader ins = new InputStreamReader(in);
            // final BufferedReader br = new BufferedReader(ins);

            final BufferedReader br =
                    new BufferedReader(new FileReader("D:\\dev\\workspace\\fm\\src\\test\\resources\\test.csv"));
            String ligne = null;
            while ((ligne = br.readLine()) != null) {
                // Retourner la ligne dans un tableau
                final String[] data = ligne.split(";");

                // Afficher le contenu du tableau
                for (final String val : data) {
                    System.out.println(val);
                }
            }
            br.close();
        } catch (final FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (final IOException e) {
            System.out.println(e.getMessage());
        }

    }
}
