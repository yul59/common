package com.uma.project;

import lombok.Data;

@Data
public class TrashClasse {

    private int id;

    private String value;

}
