package com.uma.project.coachhelper.domaine;

import lombok.Data;

import org.joda.time.DateTime;

/**
 * Instantiates a new match.
 */

/**
 * Instantiates a new match.
 */
@Data
public class Match {
    
    /** The id. */
    private int id;

    /** The date. */
    private DateTime date;

    /** The lieu. */
    // private LieuEnum lieu;

    /** The adversaire. */
    private String adversaire;

    /** The score equipe. */
    private int scoreEquipe;

    /** The score adversaire. */
    private int scoreAdversaire;

}
