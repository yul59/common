package com.uma.project.domaine;

import com.uma.project.coachhelper.domaine.Match;

import lombok.extern.slf4j.Slf4j;

import org.joda.time.DateTime;
import org.junit.Test;

@Slf4j
public class MatchTest {

    @Test
    public void toStringTest() {
        final Match match = new Match();
        match.setId(1);
        match.setAdversaire("mon adversaire");
        match.setDate(new DateTime("2016-08-10T10:00:00"));

        log.debug(match.toString());
    }

}
