/**
 * 
 */
package com.uma.project.services.json.utils;

import org.springframework.stereotype.Component;

/**
 * @author HP
 *
 */
@Component
public class JsonUtils {

}
