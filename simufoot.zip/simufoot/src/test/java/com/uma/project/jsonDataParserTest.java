/**
 * 
 */
package com.uma.project;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.junit.Test;

import com.uma.project.services.data.parser.json.JsonDataParser;

/**
 * @author HP
 *
 */
public class jsonDataParserTest {

	@Test
	public void parseTeamsTest() {
		System.out.println("test OK");

		JsonDataParser jdp = new JsonDataParser();

		String jsonData = "";

		try {
			jsonData = loadFileString("C:\\Users\\HP\\workspace\\simufoot\\target\\test-classes\\teams.json");
		} catch (IOException e) {
			e.printStackTrace();
		}

		// System.out.println(jsonData);

		System.out.println(jdp.parseTeams(jsonData).toString());
	}

	public String loadFileString(String file) throws IOException {
		BufferedReader in = new BufferedReader(new FileReader(file));
		String line;
		StringBuffer sb = new StringBuffer();
		while ((line = in.readLine()) != null) {
			// Afficher le contenu du fichier
			sb.append(line);
		}
		in.close();

		return sb.toString();
	}
}
