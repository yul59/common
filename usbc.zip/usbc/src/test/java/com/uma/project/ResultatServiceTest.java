/**
 * 
 */
package com.uma.project;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.uma.project.service.resultat.ResultatServiceImpl;

/**
 * @author HP
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class ResultatServiceTest {

	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

	@Autowired
	ResultatServiceImpl resultatService;

	@Test
	public void rechercherResultatEquipeTest() {
		String resultat = resultatService
				.rechercherResultatEquipe("16701", "3");

		assertThat(resultat).isNotEmpty();
	}
}
