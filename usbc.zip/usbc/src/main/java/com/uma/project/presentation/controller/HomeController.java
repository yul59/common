/**
 * 
 */
package com.uma.project.presentation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uma.project.service.resultat.ResultatServiceImpl;

/**
 * @author HP
 *
 */
@Controller
public class HomeController {

	@Autowired
	ResultatServiceImpl resultatService;

	@RequestMapping("/")
	String home(Model model) {
		return "index";
	}

	@RequestMapping("/resultat/{idClub}/{idEquipe}")
	@ResponseBody
	String resultat(Model model, @PathVariable String idClub,
			@PathVariable String idEquipe) {
		return resultatService.rechercherResultatEquipe(idClub, idEquipe);
	}

}
