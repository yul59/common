/**
 * 
 */
package com.uma.project.service.resultat;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * @author HP
 *
 */
@Service
public class ResultatServiceImpl {

	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

	private final String URL = "http://maritime-nord.fff.fr/competitions/php/club/club_calendrier_deta.php?sa_no=2016&cp_no=329829&ph_no=1&gp_no=3&cl_no=%_IDCLUB_%&eq_no=%_IDEQUIPE_%";

	public String rechercherResultatEquipe(String idClub, String idEquipe) {
		String url = buildUrl(idClub, idEquipe);
		StringBuffer retour = new StringBuffer();

		Document doc = null;
		try {
			doc = Jsoup.connect(url).get();

			Elements matches = doc.getElementsByClass("resultatmatch");
			for (Element match : matches) {
				Element team = match.getElementsByClass("team").first()
						.getElementsByTag("strong").first();

				Element score = match.getElementsByClass("score").first()
						.getElementsByTag("strong").first();

				String scoreText = "";
				if (score != null) {
					scoreText = score.text();
				}
				Element teamb = match.getElementsByClass("team").last()
						.getElementsByTag("strong").first();

				retour.append(team.text() + " - " + teamb.text() + " : "
						+ scoreText);
			}

			LOGGER.debug(retour.toString());

		} catch (IOException e) {
			LOGGER.error(
					"Erreur lors de la recuperation du calendrier de l'equipe",
					e);
		}

		return retour.toString();
	}

	public void classement() {
		String url = "http://maritime-nord.fff.fr/competitions/php/championnat/championnat_classement.php?sa_no=2016&cp_no=329829&ph_no=1&gp_no=3";

		Document doc = null;
		try {
			doc = Jsoup.connect(url).get();
			Element tablo = doc.getElementsByClass("tablo").first();
			Element body = tablo.getElementsByTag("tbody").first();
			for (Element ligne : body.getElementsByTag("tr")) {
				Elements tds = ligne.select("td");
				String pl = (tds.get(0).text());
				String eq = (tds.get(1).text());
				String jo = (tds.get(2).text());
				String pt = (tds.get(3).text());
				System.out.println(pl + "-" + eq + "-" + jo + "-" + pt);
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private String buildUrl(String idClub, String idEquipe) {
		return URL.replace("%_IDCLUB_%", idClub).replace("%_IDEQUIPE_%",
				idEquipe);
	}

}
